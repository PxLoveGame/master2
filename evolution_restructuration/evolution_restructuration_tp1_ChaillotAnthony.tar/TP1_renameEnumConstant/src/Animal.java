
/**
 * 
 * @author Louis Daviaud
 *
 */
public enum Animal {
	CHIEN, CHAT, LION
}